﻿using ExamenMarzo.Database;
namespace ExamenMarzo.Servicios
{
    public class TareasService
    {
        public TareasService() { }

        public async Task<List<Tarea>> GetTareasByIdAsync(int id)
        {

        }

    }
}
