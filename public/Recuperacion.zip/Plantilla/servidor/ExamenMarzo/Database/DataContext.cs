using Microsoft.EntityFrameworkCore;

namespace ExamenMarzo.Database;

public class DataContext : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("DataSource=");
    }
}
