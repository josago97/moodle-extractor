﻿namespace ExamenMarzo.Database
{
    public class Seeder
    {
    }
}
