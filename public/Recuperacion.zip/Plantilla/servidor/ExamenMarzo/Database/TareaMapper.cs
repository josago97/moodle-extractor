﻿using ExamenMarzo.Database.Models;
namespace ExamenMarzo.Database
{
    public class TareaMapper
    {
        public TareaDto ToDto (Tarea tarea)
        {
            return new TareaDto
            {
                Id = tarea.Id,
                Name = tarea.Name,
                Status = tarea.Status
            };
        }

    }
}
