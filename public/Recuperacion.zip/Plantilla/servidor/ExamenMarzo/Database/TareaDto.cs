﻿namespace ExamenMarzo.Database
{
    public class TareaDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Boolean Status { get; set; }
    }
}
