﻿namespace ExamenMarzo.Database.Models
{
    public class Tarea
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Boolean State { get; set; }

    }
}
