﻿namespace ExamenMarzo.Database
{
    public class UnitOfWork
    {
    }
}
