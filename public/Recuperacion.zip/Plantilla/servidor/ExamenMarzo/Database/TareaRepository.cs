﻿
namespace ExamenMarzo.Database
{
    public class TareaRepository
    {
        public async Task<List<Tarea>>GetAllTareasAsync(int tareaId)
        {
            return await GetQueriable()
                .where(t => t.Id != tareaId)
                .ToList Async();
        }
    }
}
