﻿using ExamenMarzo.Servicios;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ExamenMarzo.Database;

namespace ExamenMarzo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TareasController : ControllerBase
    {
        private readonly TareasService _tareasServices;

        [HttpGet("{id}")]
        public async Task<TareaDto> GetTareaById(int id)
        {
            TareaDto tareaDto = await _tareasServices.GetTareasByIdAsync(id);

            return tareaDto;
        }

        [HttpGet]
        public async Task<TareaDto> GetAllTareasAsync()
        {
            
        }

        [HttpDelete("{id}")]
        public async Task<TareaDto> DeleteTarea(int id)
        {

        }

        [HttpPost("{id}")]
        public async Task<TareaDto> UpdateTarea(int id)
        {

        }
    }
}
