import { Component } from '@angular/core';

@Component({
  selector: 'app-work-list',
  standalone: true,
  imports: [],
  templateUrl: './work-list.component.html',
  styleUrl: './work-list.component.css'
})
export class WorkListComponent {
  
}
