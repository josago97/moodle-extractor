import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-edit-work',
  standalone: true,
  imports: [],
  templateUrl: './create-edit-work.component.html',
  styleUrl: './create-edit-work.component.css'
})
export class CreateEditWorkComponent implements OnInit {

  constructor(private route: ActivatedRoute) { }

  async ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
  }
}
